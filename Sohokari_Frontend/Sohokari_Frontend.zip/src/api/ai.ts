import client from './client';
import type { Provider } from '@app-types/models';

type ChatRequest = {
  message: string;
  latitude: number;
  longitude: number;
  sessionId?: string;
};

type ChatResponse = {
  reply: string;
  providers?: Provider[];
  sessionId?: string;
};

const chat = async (payload: ChatRequest): Promise<ChatResponse> => {
  const { data } = await client.post<ChatResponse>('/ai/chat', payload);
  return data;
};

export const aiApi = {
  chat,
};
