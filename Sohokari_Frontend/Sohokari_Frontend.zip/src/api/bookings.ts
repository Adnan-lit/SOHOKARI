import client from './client';
import { Booking, CreateBookingRequest } from '@types/models';
import { BookingStatus } from '@constants/config';

export const bookingsApi = {
  create: async (data: CreateBookingRequest): Promise<Booking> => {
    const res = await client.post<Booking>('/bookings', data);
    return res.data;
  },

  getMy: async (status?: BookingStatus): Promise<Booking[]> => {
    const res = await client.get<Booking[]>('/bookings/my', {
      params: status ? { status } : undefined,
    });
    return res.data;
  },

  getById: async (id: string): Promise<Booking> => {
    // Backend may not have a direct getById — fall back to fetching from /my
    const res = await client.get<Booking[]>('/bookings/my');
    const found = res.data.find(b => b._id === id);
    if (!found) throw new Error('Booking not found');
    return found;
  },

  accept: async (id: string): Promise<Booking> => {
    const res = await client.put<Booking>(`/bookings/${id}/accept`);
    return res.data;
  },

  reject: async (id: string, reason: string): Promise<Booking> => {
    const res = await client.put<Booking>(`/bookings/${id}/reject`, { reason });
    return res.data;
  },

  start: async (id: string): Promise<Booking> => {
    const res = await client.put<Booking>(`/bookings/${id}/start`);
    return res.data;
  },

  complete: async (id: string): Promise<Booking> => {
    const res = await client.put<Booking>(`/bookings/${id}/complete`);
    return res.data;
  },

  cancel: async (id: string, reason: string): Promise<Booking> => {
    const res = await client.put<Booking>(`/bookings/${id}/cancel`, { reason });
    return res.data;
  },
};