import client from './client';
import type { ChatMessage, Conversation, Notification } from '@app-types/models';

type SendMessagePayload = {
  bookingId: string;
  receiverId: string;
  content: string;
  messageType: 'TEXT' | 'IMAGE' | 'SYSTEM';
};

const getConversations = async (): Promise<Conversation[]> => {
  const { data } = await client.get<Conversation[]>('/chat/conversations');
  return data;
};

const getMessages = async (bookingId: string): Promise<ChatMessage[]> => {
  const { data } = await client.get<ChatMessage[]>(`/chat/messages/${bookingId}`);
  return data;
};

const sendMessage = async (payload: SendMessagePayload): Promise<ChatMessage> => {
  const { data } = await client.post<ChatMessage>('/chat/messages', payload);
  return data;
};

const getNotifications = async (): Promise<Notification[]> => {
  const { data } = await client.get<Notification[]>('/notifications');
  return data;
};

const markAllRead = async (): Promise<void> => {
  await client.post('/notifications/read-all');
};

export const chatApi = {
  getConversations,
  getMessages,
  sendMessage,
};

export const notificationsApi = {
  getAll: getNotifications,
  markAllRead,
};
