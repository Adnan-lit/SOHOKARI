import client from './client';
import type { Provider, Reputation } from '@app-types/models';
import type { ServiceCategory } from '@constants/config';

type NearbyParams = {
  lat: number;
  lng: number;
  radius?: number;
  category?: ServiceCategory;
};

type SearchParams = {
  q?: string;
  category?: ServiceCategory;
  minRating?: number;
  maxPrice?: number;
  available?: boolean;
  sortBy?: 'PRICE' | 'RATING';
};

const getNearby = async (params: NearbyParams): Promise<Provider[]> => {
  const { data } = await client.get<Provider[]>('/providers/nearby', { params });
  return data;
};

const search = async (params: SearchParams): Promise<Provider[]> => {
  const { data } = await client.get<Provider[]>('/providers/search', { params });
  return data;
};

const getById = async (providerId: string): Promise<Provider> => {
  const { data } = await client.get<Provider>(`/providers/${providerId}`);
  return data;
};

const getReputation = async (providerId: string): Promise<Reputation> => {
  const { data } = await client.get<Reputation>(`/providers/${providerId}/reputation`);
  return data;
};

export const providersApi = {
  getNearby,
  search,
  getById,
  getReputation,
};
