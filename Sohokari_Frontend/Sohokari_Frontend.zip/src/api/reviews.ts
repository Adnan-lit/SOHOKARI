import client from './client';
import type { Review } from '@app-types/models';

const getByProvider = async (providerId: string): Promise<Review[]> => {
  const { data } = await client.get<Review[]>(`/reviews/provider/${providerId}`);
  return data;
};

const checkExists = async (bookingId: string): Promise<boolean> => {
  const { data } = await client.get<{ exists?: boolean }>(`/reviews/exists/${bookingId}`);
  return data.exists ?? false;
};

export const reviewsApi = {
  getByProvider,
  checkExists,
};
