export const BASE_URL =
  process.env.EXPO_PUBLIC_API_BASE_URL ?? 'https://sohokari-backend.onrender.com';

export const WS_URL =
  process.env.EXPO_PUBLIC_WS_URL ?? 'wss://sohokari-backend.onrender.com/ws/chat';

export const API_TIMEOUT = 15000;

export type ServiceCategory =
  | 'PLUMBING'
  | 'ELECTRICIAN'
  | 'CLEANING'
  | 'AC_REPAIR'
  | 'PAINTING'
  | 'CARPENTRY'
  | 'APPLIANCE_REPAIR'
  | 'PEST_CONTROL'
  | 'BEAUTY'
  | 'TUTORING';

export const SERVICE_CATEGORIES: { key: ServiceCategory; label: string; icon: string }[] = [
  { key: 'PLUMBING',        label: 'Plumbing',        icon: 'water-outline' },
  { key: 'ELECTRICIAN',     label: 'Electrician',     icon: 'flash-outline' },
  { key: 'CLEANING',        label: 'Cleaning',        icon: 'sparkles-outline' },
  { key: 'AC_REPAIR',       label: 'AC Repair',       icon: 'snow-outline' },
  { key: 'PAINTING',        label: 'Painting',        icon: 'brush-outline' },
  { key: 'CARPENTRY',       label: 'Carpentry',       icon: 'hammer-outline' },
  { key: 'APPLIANCE_REPAIR',label: 'Appliance Repair',icon: 'build-outline' },
  { key: 'PEST_CONTROL',    label: 'Pest Control',    icon: 'bug-outline' },
  { key: 'BEAUTY',          label: 'Beauty',          icon: 'color-palette-outline' },
  { key: 'TUTORING',        label: 'Tutoring',        icon: 'school-outline' },
];

export type BookingStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'REJECTED';

export const BOOKING_STATUSES: BookingStatus[] = [
  'PENDING',
  'ACCEPTED',
  'IN_PROGRESS',
  'COMPLETED',
  'CANCELLED',
  'REJECTED',
];

export const DEFAULT_LOCATION = {
  latitude: 23.8103,
  longitude: 90.4125,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export const NEARBY_RADIUS_KM = 10;